from mazegen.maze_generator import MazeGenerator, Cell

__all__ = ["MazeGenerator", "Cell"]
